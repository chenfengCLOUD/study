//Content.qml
import QtQuick
import QtMultimedia
import "videoplayer.js" as Controller

Item {
    //id:content // 定不定义都无所谓
    anchors.fill: parent

    property alias dialog: _dialog
    property alias player: _player

    Dialogs{
        id:_dialog
        fileOpen.onRejected:{
            return;
        }
        fileOpen{
            onAccepted:{
                let filePath = fileOpen.selectedFile;
                _player.source = filePath
                console.log("mkv or avi path: ",filePath)
                Controller.play()
            }
        }
    }

    Rectangle {
        id:rec
        anchors.fill:parent
        color: "black"

        MediaPlayer {
            id: _player
            videoOutput: videoOutput
            //videoOutput: VideoOutput{anchors.fill:parent} // error???
            onMediaStatusChanged: {
                if(mediaStatus === MediaPlayer.LoadedMedia) {
                    console.log("Audio loaded successfully")
                }else if(mediaStatus === MediaPlayer.InvalidMedia){
                    console.log("Failed to load audio:",errorString)
                    _dialog.openFail.open()
                }
            }
            onPlaybackStateChanged: {
                Controller.updateButtonStates()
            }
            //Action中或者这里更新状态，二选一
            //但Action有个bug,因为设置了打开文件即播放，并没有点击start按钮
            //所以需要再按一次start后才能按其他的按钮
        }

        VideoOutput {
            id: videoOutput
            anchors.fill: parent
        }

        TapHandler{
            onDoubleTapped:{
                Controller.fullScreen()
            }
        }
    }
}
